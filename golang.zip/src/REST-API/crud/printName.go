package crud

import "fmt"

func PrintName(name string) {
	fmt.Println("Hiii Name is Govinda")
}
