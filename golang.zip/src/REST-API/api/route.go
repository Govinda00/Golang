package api

import (
	"database/sql"
	"net/http"

	"github.com/gorilla/mux"
)

func RegisterHandler(db *sql.DB) {
	router := mux.NewRouter()

	router.HandleFunc("/printname", PrintName)
	router.HandleFunc("/user/create", CreateUser(db)).Methods("POST")
	router.HandleFunc("/user/update/{id}", UpdateUser(db)).Methods("PUT")
	router.HandleFunc("/user/delete/{id}", DeleteUser(db)).Methods("DELETE")
	router.HandleFunc("/user/list", ListOfUser(db))

	router.HandleFunc("/callexternalapi", CallExternalApi)

	http.ListenAndServe(":8086", router)
}
